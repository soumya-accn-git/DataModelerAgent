import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import streamlit as st
import json
import pandas as pd
from agent.cdm_builder import result_to_mermaid, result_to_jsonld

def render_output(result: dict):
    st.divider()
    st.subheader("📊 Conceptual Data Model")

    tab_diagram, tab_entities, tab_relations, tab_json = st.tabs([
        "🗺️ Diagram", "📦 Entities", "🔗 Relationships", "📋 JSON-LD"
    ])

    with tab_diagram:
        _render_diagram(result)

    with tab_entities:
        _render_entities(result)

    with tab_relations:
        _render_relationships(result)

    with tab_json:
        _render_jsonld(result)


def _render_diagram(result):
    mermaid_str = result_to_mermaid(result)

    st.markdown("**Entity-Relationship Diagram**")
    st.markdown(
        f"""
```mermaid
{mermaid_str}
```
""",
    )

    col1, col2 = st.columns(2)
    with col1:
        st.download_button(
            "⬇️ Download Mermaid (.mmd)",
            data=mermaid_str,
            file_name="cdm.mmd",
            mime="text/plain",
            use_container_width=True,
        )
    with col2:
        st.download_button(
            "⬇️ Download JSON-LD (.jsonld)",
            data=json.dumps(result_to_jsonld(result), indent=2),
            file_name="cdm.jsonld",
            mime="application/json",
            use_container_width=True,
        )


def _render_entities(result):
    entities = result.get("entities", [])
    if not entities:
        st.info("No entities found.")
        return

    st.markdown(f"**{len(entities)} entities extracted**")

    rows = []
    for e in entities:
        rows.append({
            "Entity": e.get("name", ""),
            "Type": e.get("type", ""),
            "Description": e.get("description", ""),
            "Ontology match": ", ".join(e.get("ontology_matches", [])),
            "Source sentence": e.get("source", ""),
        })

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)

    st.download_button(
        "⬇️ Download entities CSV",
        data=df.to_csv(index=False),
        file_name="entities.csv",
        mime="text/csv",
    )


def _render_relationships(result):
    relationships = result.get("relationships", [])
    if not relationships:
        st.info("No relationships found.")
        return

    st.markdown(f"**{len(relationships)} relationships detected**")

    rows = []
    for r in relationships:
        rows.append({
            "From": r.get("from_entity", ""),
            "Relationship": r.get("label", ""),
            "To": r.get("to_entity", ""),
            "Cardinality": r.get("cardinality", ""),
            "Ontology type": r.get("ontology_type", ""),
        })

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)

    st.download_button(
        "⬇️ Download relationships CSV",
        data=df.to_csv(index=False),
        file_name="relationships.csv",
        mime="text/csv",
    )


def _render_jsonld(result):
    jsonld = result_to_jsonld(result)
    st.code(json.dumps(jsonld, indent=2), language="json")
