"""
Step 2 — Entity extraction
Uses the LLM to identify business entities from the BRD text.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from agent.ollama_client import chat, extract_json

SYSTEM_PROMPT = """You are a senior data architect. Your task is to extract all
business entities from a Business Requirements Document (BRD).

An entity is a distinct, real-world concept that the business needs to track
or manage — such as a Customer, Order, Product, Invoice, Employee, etc.

You must respond ONLY with a valid JSON object, no explanation, no markdown.
"""

USER_TEMPLATE = """
Analyse the following BRD text and extract all business entities.

For each entity provide:
- "name": PascalCase entity name (e.g. "CustomerOrder")
- "type": one of [core, supporting, reference, event]
  - core: central to the business domain
  - supporting: exists to support core entities
  - reference: lookup/classification tables
  - event: represents a business event or transaction
- "description": one sentence describing what this entity represents
- "attributes": list of likely key attributes (max 6)
- "source": the exact phrase or sentence from the BRD that implies this entity

Return a JSON object with a single key "entities" containing a list.

BRD TEXT:
---
{brd_text}
---

JSON response:
"""


def extract_entities(
    brd_text: str,
    ollama_url: str,
    model: str,
    temperature: float = 0.1,
) -> list[dict]:
    """
    Returns a list of entity dicts:
    {name, type, description, attributes, source}
    """
    # Chunk if very long (keep to ~6000 chars for smaller models)
    text_chunk = brd_text[:6000] if len(brd_text) > 6000 else brd_text

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": USER_TEMPLATE.format(brd_text=text_chunk)},
    ]

    raw = chat(
        base_url=ollama_url,
        model=model,
        messages=messages,
        temperature=temperature,
        format="json",
    )

    data = extract_json(raw)

    if isinstance(data, list):
        entities = data
    elif isinstance(data, dict):
        entities = data.get("entities", [])
    else:
        entities = []

    # Normalise
    cleaned = []
    for e in entities:
        if not isinstance(e, dict):
            continue
        name = e.get("name", "").strip()
        if not name:
            continue
        cleaned.append({
            "name": name,
            "type": e.get("type", "core"),
            "description": e.get("description", ""),
            "attributes": e.get("attributes", []),
            "source": e.get("source", ""),
            "ontology_matches": [],  # filled in step 4
        })

    return cleaned
